extern int func1a();
extern int b;
int func2(){
    funct();
}