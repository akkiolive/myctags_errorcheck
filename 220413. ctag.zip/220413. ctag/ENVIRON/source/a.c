int func1();
int a;
asfasdfsadf();
int func1(){
    nkonononononon();
}