extern double hoge;
int a;