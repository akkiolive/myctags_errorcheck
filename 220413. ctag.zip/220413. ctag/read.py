with open("tags.json", "r") as f:
    content = f.read()


import json
p = json.load(content)
print(p)