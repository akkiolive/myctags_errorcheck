extern int func1a();

int func2(){
    funct();
}